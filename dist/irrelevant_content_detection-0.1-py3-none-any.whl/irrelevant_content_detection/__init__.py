# __init__.py

from .detector import (
    detect_irrelevant_contents,
    clean_irrelevant_contents,
    detect_irrelevant_html,
    clean_irrelevant_html
)
