# irrelevant-content-detection
A Python package for detecting irrelevant content in texts.
